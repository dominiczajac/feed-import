# Feed Import

Wtyczka WordPressa importuje produkty Google Merchant Center z feeda XML do własnego typu wpisu `mg_feed_product`.

## Instalacja i import

1. Zainstaluj ZIP w panelu WordPressa przez **Wtyczki → Dodaj wtyczkę → Wyślij wtyczkę na serwer** i włącz wtyczkę.
2. Otwórz **Produkty z feeda → Import XML**. Formularz domyślnie wskazuje `https://magento.mgprojekt.com.pl/media/feed/gmc.xml`.
3. Kliknij **Importuj produkty**. Wynik znajdziesz w menu **Produkty z feeda**. Dane takie jak cena, dostępność i adres zdjęcia są widoczne w sekcji **Dane z feeda** po otwarciu wpisu.

Jeśli WordPress odrzuca adres przed pobraniem, sprawdź na serwerze WordPressa rozpoznawanie domeny na publiczny adres IP i dostęp do portu 443 dla HTTPS. Możesz od razu pobrać oryginalny XML w przeglądarce i wskazać go w polu **Plik XML**. Import pliku obsługuje również kopię XML zaczynającą się od angielskiego komunikatu przeglądarki „This XML file does not appear to have any style information associated with it. The document tree is shown below.”. Zachowaj adres źródła z formularza, żeby oba tryby importu aktualizowały te same wpisy. Limit samej wtyczki to 16 MiB, a PHP może mieć niższy limit przesyłania. Zdjęcia nadal pobiera serwer WordPressa.

Wymagania to WordPress 6.2+, PHP 8.0+ z rozszerzeniem DOM, MySQL lub MariaDB i dostęp HTTP(S) do feeda po stronie serwera WordPressa. Obsługiwany format to RSS z elementami `rss/channel/item`, polami Google Merchant Center w przestrzeni nazw `http://base.google.com/ns/1.0` i standardowymi polami RSS.

Import wymaga uprawnień administratora. Wtyczka zapisuje wpisy ze statusem **Prywatny** i przypisuje je do kategorii **Importowane produkty** w osobnej, niepublicznej taksonomii. Typ wpisu nie ma publicznych adresów ani endpointu REST. Nie wymaga WooCommerce.

Ponowny import z tego samego adresu aktualizuje wpisy według identyfikatora produktu. Zmiana adresu oznacza osobne źródło. Produkty usunięte z feeda pozostają w WordPressie. Import uruchamia się ręcznie i przyjmuje do 5000 pozycji oraz do 16 MiB XML na żądanie.

## Przygotowanie wpisu dla FS Poster

- Tytuł i opis projektu trafiają do standardowych pól wpisu. Treść i zajawka zawierają publiczny adres projektu z XML. W szablonie wpisu społecznościowego użyj tytułu i zajawki, aby odsyłać do strony produktu.
- Główne zdjęcie z `g:image_link` trafia do biblioteki mediów i staje się obrazkiem wyróżniającym. Pobieranie odbywa się w tle przez WP-Cron. Stan lub błąd widać w sekcji **Dane z feeda**. Ponowny import ponawia przygotowanie brakujących zdjęć i zachowuje ręcznie wybrane obrazki wyróżniające.
- Przy edycji produktu sekcja **Zdjęcia do galerii** pokazuje główne zdjęcie i dodatkowe adresy z `g:additional_image_link`, zaczynając od ostatniego zdjęcia z feeda. Zaznacz zdjęcia pojedynczo lub użyj przycisku **Zaznacz od końca**, aby dodać podaną liczbę końcowych zdjęć do bieżącego wyboru. Zapisz wpis, aby WP-Cron pobrał wybrane pliki do biblioteki mediów i dodał je do galerii w kolejności z feeda. Większy wybór może wymagać więcej czasu na pobranie. Główne zdjęcie jest też osobnym obrazkiem wyróżniającym.
- Pliki muszą być dostępne bez przekierowania pod publicznym adresem HTTPS, w formacie JPEG, PNG lub WebP, do 8 MiB i 16 megapikseli. Adresy dodatkowych zdjęć podane w XML jako HTTP są sprawdzane przez HTTPS. Adres pliku w bibliotece mediów może być publiczny mimo prywatności wpisu.
- Ceny, SKU i pozostałe importowane atrybuty są dostępne w sekcji **Dane z feeda**.

### Gdy FS Poster pokazuje tylko zwykłe wpisy

1. W **Produktach z feeda** otwórz produkt, zaznacz zdjęcia i zapisz wpis. Po pobraniu wybranych zdjęć kliknij **Przygotuj szkic dla FS Poster**.
2. WordPress otworzy standardowy wpis ze statusem **Szkic** w kategorii **Produkty do social media**. Zawiera tytuł, treść, zajawkę z publicznym adresem produktu i blok galerii z wybranymi zdjęciami. Pierwsze wybrane zdjęcie jest obrazkiem wyróżniającym. Przy pustym wyborze szkic korzysta z obrazka wyróżniającego produktu.
3. Otwórz narzędzia FS Poster w edytorze zwykłego wpisu lub wybierz szkic w FS Poster, jeśli jego wersja to umożliwia. W szablonie korzystaj z adresu produktu w zajawce. Sprawdź na podglądzie, czy kanał otrzymał wybrane zdjęcia.

Kliknięcie ponownie przy tych samych danych otwiera istniejący szkic. Zmiana danych lub wyboru zdjęć pozwala utworzyć nowy szkic bez nadpisania poprzedniego. Produkt źródłowy pozostaje prywatny. Utworzenie szkicu nie opublikuje wpisu w WordPressie ani w mediach społecznościowych.

FS Poster może ukrywać szkice i kategorie bez opublikowanych wpisów lub udostępniać wyłącznie obrazek wyróżniający. W takim przypadku skorzystaj z **Direct Share**, jeśli jest dostępny, i dołącz wybrane zdjęcia ręcznie. Publikacja zwykłego szkicu przyciskiem **Opublikuj** może udostępnić go publicznie na stronie WordPressa.
