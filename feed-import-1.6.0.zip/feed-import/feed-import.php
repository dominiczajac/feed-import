<?php
/**
 * Plugin Name: Feed Import
 * Description: Import produktów z Google Merchant Center XML do prywatnego katalogu WordPressa.
 * Version: 1.6.0
 * Requires at least: 6.2
 * Requires PHP: 8.0
 */

defined('ABSPATH') || exit;

final class MG_Feed_Import {
    private const POST_TYPE = 'mg_feed_product';
    private const TAXONOMY = 'mg_feed_category';
    private const TERM = 'importowane-produkty';
    private const OPTION = 'mg_feed_import_url';
    private const FS_POSTER_DISCOVERY = 'mg_feed_fs_poster_discovery';
    private const DEFAULT_URL = 'https://magento.mgprojekt.com.pl/media/feed/gmc.xml';
    private const MAX_BYTES = 16 * 1024 * 1024;
    private const MAX_PRODUCTS = 5000;
    private const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
    private const IMAGE_EVENT = 'mg_feed_import_featured_image';
    private const GALLERY_EVENT = 'mg_feed_import_gallery_image';
    private const IMAGE_SOURCE = '_mg_feed_attachment_source';
    private const IMAGE_ERROR = '_mg_feed_image_error';
    private const EXTRA_IMAGES = '_mg_feed_additional_images';
    private const GALLERY_SELECTION = '_mg_feed_gallery_selection';
    private const GALLERY_MEDIA = '_mg_feed_gallery_media';
    private const GALLERY_ERROR = '_mg_feed_gallery_error_';
    private const SOCIAL_CATEGORY = 'produkty-do-social-media';
    private const SOCIAL_DRAFT_SOURCE = '_mg_feed_social_draft_source';
    private const GOOGLE_NS = 'http://base.google.com/ns/1.0';

    private const FIELDS = [
        'id' => 'Identyfikator w feedzie',
        'sku' => 'SKU',
        'price' => 'Cena',
        'sale_price' => 'Cena promocyjna',
        'availability' => 'Dostępność',
        'brand' => 'Marka',
        'gtin' => 'GTIN',
        'mpn' => 'MPN',
        'condition' => 'Stan',
        'product_type' => 'Typ produktu w feedzie',
        'google_product_category' => 'Kategoria Google',
        'link' => 'Adres produktu',
        'image_link' => 'Adres zdjęcia',
    ];

    public static function boot(): void {
        add_action('init', [self::class, 'register_content']);
        add_action('admin_menu', [self::class, 'add_menu']);
        add_action('admin_init', [self::class, 'register_settings']);
        add_action('admin_post_mg_feed_import', [self::class, 'handle_import']);
        add_action('admin_post_mg_feed_social_draft', [self::class, 'handle_social_draft']);
        add_action('add_meta_boxes_' . self::POST_TYPE, [self::class, 'add_details_box']);
        add_action('admin_footer-post.php', [self::class, 'render_social_form']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue_gallery_media']);
        add_action(self::IMAGE_EVENT, [self::class, 'import_featured_image']);
        add_action(self::GALLERY_EVENT, [self::class, 'import_gallery_image'], 10, 2);
        add_action('save_post_' . self::POST_TYPE, [self::class, 'save_gallery']);
    }

    public static function register_content(): void {
        $discoverable = is_admin() && get_option(self::FS_POSTER_DISCOVERY) === '1' && current_user_can('manage_options');

        register_post_type(self::POST_TYPE, [
            'labels' => [
                'name' => 'Produkty z feeda',
                'singular_name' => 'Produkt z feeda',
                'edit_item' => 'Edytuj produkt z feeda',
            ],
            'public' => $discoverable,
            'publicly_queryable' => false,
            'exclude_from_search' => true,
            'show_ui' => true,
            'show_in_rest' => false,
            'show_in_nav_menus' => false,
            'rewrite' => false,
            'query_var' => false,
            'supports' => ['title', 'editor', 'excerpt', 'thumbnail'],
            'map_meta_cap' => true,
            'capabilities' => ['create_posts' => 'do_not_allow'],
            'menu_icon' => 'dashicons-products',
        ]);

        register_taxonomy(self::TAXONOMY, self::POST_TYPE, [
            'label' => 'Kategorie produktów z feeda',
            'hierarchical' => true,
            'public' => $discoverable,
            'publicly_queryable' => false,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => false,
            'show_in_nav_menus' => false,
            'rewrite' => false,
            'query_var' => false,
        ]);
    }

    public static function register_settings(): void {
        register_setting('mg_feed_fs_poster', self::FS_POSTER_DISCOVERY, [
            'type' => 'string',
            'default' => '0',
            'sanitize_callback' => static fn($value) => $value === '1' ? '1' : '0',
        ]);
    }

    public static function add_menu(): void {
        add_submenu_page(
            'edit.php?post_type=' . self::POST_TYPE,
            'Import XML',
            'Import XML',
            'manage_options',
            'mg-feed-import',
            [self::class, 'render_page']
        );
    }

    public static function render_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $url = get_option(self::OPTION, self::DEFAULT_URL);
        ?>
        <div class="wrap">
            <h1>Import produktów z XML</h1>
            <?php
            if (isset($_GET['imported'], $_GET['skipped'], $_GET['failed'])) {
                $imported = absint($_GET['imported']);
                $skipped = absint($_GET['skipped']);
                $failed = absint($_GET['failed']);
                $notice = $failed || $skipped ? 'notice-warning' : 'notice-success';
                ?>
                <div class="notice <?php echo esc_attr($notice); ?>"><p>
                    <?php echo esc_html(sprintf(
                        'Zapisano lub zaktualizowano: %d. Pominięto bez ID lub tytułu: %d. Błędy zapisu: %d.',
                        $imported,
                        $skipped,
                        $failed
                    )); ?>
                </p></div>
                <?php
            }
            ?>
            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="mg_feed_import">
                <?php wp_nonce_field('mg_feed_import'); ?>
                <p><label for="mg-feed-url">Adres feeda Google Merchant Center (XML)</label></p>
                <input id="mg-feed-url" class="large-text" name="feed_url" type="url"
                    value="<?php echo esc_attr($url); ?>" required>
                <p>
                    <label for="mg-feed-file">Plik XML (opcjonalnie)</label>
                    <input id="mg-feed-file" type="file" name="feed_file" accept=".xml,application/xml,text/xml">
                </p>
                <p class="description">Jeśli wybierzesz plik, import użyje go zamiast pobierać feed.
                    Zachowaj ten sam adres, aby aktualizować wpisy z tego źródła.</p>
                <?php submit_button('Importuj produkty'); ?>
            </form>
            <hr>
            <h2>FS Poster</h2>
            <form action="<?php echo esc_url(admin_url('options.php')); ?>" method="post">
                <?php settings_fields('mg_feed_fs_poster'); ?>
                <label>
                    <input type="checkbox" name="<?php echo esc_attr(self::FS_POSTER_DISCOVERY); ?>" value="1"
                        <?php checked(get_option(self::FS_POSTER_DISCOVERY), '1'); ?>>
                    Włącz wykrywanie produktów i kategorii w panelu administratora
                </label>
                <p class="description">Ta opcja pomaga wtyczkom, które w panelu wyświetlają tylko typy i taksonomie oznaczone jako publiczne.
                    Produkty nadal mają status Prywatny.</p>
                <?php submit_button('Zapisz ustawienie FS Poster', 'secondary'); ?>
            </form>
        </div>
        <?php
    }

    public static function add_details_box(): void {
        add_meta_box('mg-feed-details', 'Dane z feeda', [self::class, 'render_details'], self::POST_TYPE);
        add_meta_box('mg-feed-gallery', 'Zdjęcia do galerii', [self::class, 'render_gallery'], self::POST_TYPE);
        if (current_user_can('manage_options')) {
            add_meta_box('mg-feed-social', 'FS Poster', [self::class, 'render_social_box'], self::POST_TYPE, 'side');
        }
    }

    public static function render_social_box(): void {
        ?>
        <p>Zapisz wybór zdjęć przed utworzeniem szkicu. Szkic pojawi się w menu Wpisy w kategorii Produkty do social media.</p>
        <button type="submit" class="button button-primary" form="mg-feed-social-form">Przygotuj szkic dla FS Poster</button>
        <?php
    }

    public static function enqueue_gallery_media(string $page): void {
        if ($page === 'post.php' && get_current_screen()?->post_type === self::POST_TYPE && current_user_can('upload_files')) {
            wp_enqueue_media();
        }
    }

    public static function render_social_form(): void {
        $post = get_post();
        if (!$post || $post->post_type !== self::POST_TYPE || !current_user_can('manage_options')) {
            return;
        }
        ?>
        <form id="mg-feed-social-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
            <input type="hidden" name="action" value="mg_feed_social_draft">
            <input type="hidden" name="product_id" value="<?php echo esc_attr((string) $post->ID); ?>">
            <?php wp_nonce_field('mg_feed_social_draft_' . $post->ID); ?>
        </form>
        <?php
    }

    public static function handle_social_draft(): void {
        $value = $_POST['product_id'] ?? '';
        $product_id = is_string($value) ? absint($value) : 0;
        $product = get_post($product_id);
        if (!$product_id || !$product || $product->post_type !== self::POST_TYPE
            || $product->post_status !== 'private' || !current_user_can('manage_options')
            || !current_user_can('edit_post', $product_id)
            || !current_user_can(get_post_type_object('post')->cap->create_posts)
            || !current_user_can(get_taxonomy('category')->cap->assign_terms)) {
            wp_die('Brak uprawnień do przygotowania szkicu tego produktu.', '', ['response' => 403]);
        }
        check_admin_referer('mg_feed_social_draft_' . $product_id);

        $draft = self::create_social_draft($product);
        if (is_wp_error($draft)) {
            wp_die(esc_html($draft->get_error_message()), 'FS Poster', ['back_link' => true]);
        }

        wp_safe_redirect(get_edit_post_link($draft, 'raw'));
        exit;
    }

    private static function create_social_draft(WP_Post $product) {
        $selection = array_filter((array) get_post_meta($product->ID, self::GALLERY_SELECTION, true));
        $images = self::gallery_attachments($product->ID);
        $missing = count(array_diff_key(array_flip($selection), $images));
        if ($missing) {
            return new WP_Error('mg_feed_gallery_pending', sprintf(
                'Brak %d z %d wybranych zdjęć w Bibliotece mediów. Jeśli pobieranie czeka lub się nie powiodło, użyj opcji Wybierz z mediów przy tych zdjęciach, a następnie zapisz produkt.',
                $missing,
                count($selection)
            ));
        }
        $image_ids = [];
        foreach ($selection as $url) {
            $image_ids[] = $images[$url];
        }

        $thumbnail = $image_ids[0] ?? (int) get_post_thumbnail_id($product->ID);
        $content = wpautop(esc_html(wp_strip_all_tags(strip_shortcodes(self::without_gallery($product->post_content)))));
        $image_blocks = [];
        foreach ($image_ids as $id) {
            $url = wp_get_attachment_image_url($id, 'large');
            if (!$url) {
                return new WP_Error('mg_feed_gallery_url', 'WordPress nie zwrócił adresu jednego z wybranych zdjęć.');
            }
            $image_blocks[] = sprintf(
                '<!-- wp:image {"id":%d,"sizeSlug":"large","linkDestination":"none"} -->'
                . '<figure class="wp-block-image size-large"><img src="%s" alt="%s" class="wp-image-%d"/></figure>'
                . '<!-- /wp:image -->',
                $id,
                esc_url($url),
                esc_attr(get_post_meta($id, '_wp_attachment_image_alt', true)),
                $id
            );
        }
        if ($image_blocks) {
            $content .= "\n\n<!-- wp:gallery -->\n<figure class=\"wp-block-gallery has-nested-images columns-default is-cropped\">"
                . implode("\n\n", $image_blocks)
                . "</figure>\n<!-- /wp:gallery -->";
        }

        $fingerprint = hash('sha256', serialize([
            $product->ID, $product->post_title, $product->post_excerpt, $content, $thumbnail,
        ]));
        $existing = get_posts([
            'post_type' => 'post',
            'post_status' => 'draft',
            'author' => get_current_user_id(),
            'meta_key' => self::SOCIAL_DRAFT_SOURCE,
            'meta_value' => $fingerprint,
            'numberposts' => 1,
            'fields' => 'ids',
        ]);
        if ($existing) {
            return $existing[0];
        }

        $category = term_exists(self::SOCIAL_CATEGORY, 'category');
        if (!$category) {
            if (!current_user_can(get_taxonomy('category')->cap->manage_terms)) {
                return new WP_Error('mg_feed_social_category', 'Utworzenie kategorii wymaga uprawnień do zarządzania kategoriami.');
            }
            $category = wp_insert_term('Produkty do social media', 'category', ['slug' => self::SOCIAL_CATEGORY]);
        }
        if (is_wp_error($category)) {
            return $category;
        }

        return wp_insert_post(wp_slash([
            'post_type' => 'post',
            'post_status' => 'draft',
            'post_title' => $product->post_title,
            'post_content' => $content,
            'post_excerpt' => $product->post_excerpt,
            'post_category' => [(int) $category['term_id']],
            'meta_input' => [self::SOCIAL_DRAFT_SOURCE => $fingerprint],
            '_thumbnail_id' => $thumbnail,
        ]), true);
    }

    public static function render_gallery(WP_Post $post): void {
        $images = self::gallery_options($post->ID);
        if (!$images) {
            echo '<p>Zaimportuj produkt, aby zobaczyć zdjęcia z feeda.</p>';
            return;
        }

        $selected = (array) get_post_meta($post->ID, self::GALLERY_SELECTION, true);
        $overrides = self::gallery_media_overrides($post->ID);
        $shown = self::gallery_attachments($post->ID);
        $can_upload = current_user_can('upload_files');
        wp_nonce_field('mg_feed_gallery_' . $post->ID, 'mg_feed_gallery_nonce');
        ?>
        <p>Lista zaczyna się od końca feeda, gdzie zwykle są zdjęcia realizacji.
            Zaznacz zdjęcia i zapisz wpis, aby pobrać je w tle.
            Jeśli pobranie się nie powiedzie, możesz wgrać plik lub wskazać go w Bibliotece mediów.</p>
        <p>
            <label for="mg-feed-gallery-count">Liczba zdjęć od końca feeda</label>
            <input id="mg-feed-gallery-count" type="number" min="1" max="<?php echo count($images); ?>"
                value="<?php echo min(20, count($images)); ?>" class="small-text">
            <button type="button" class="button" id="mg-feed-gallery-select-tail">Zaznacz od końca</button>
        </p>
        <ul id="mg-feed-gallery-images">
        <?php
        foreach (array_reverse($images) as $url) {
            $is_selected = in_array($url, $selected, true);
            $pending = $is_selected && wp_next_scheduled(self::GALLERY_EVENT, [$post->ID, $url]);
            $label = basename((string) wp_parse_url($url, PHP_URL_PATH)) ?: $url;
            $key = hash('sha256', $url);
            $override = $overrides[$key] ?? 0;
            $status = '';
            if ($is_selected && isset($shown[$url])) {
                $status = '✓ W bibliotece';
            } elseif ($pending) {
                $status = 'Oczekuje na pobranie przez WP-Cron';
            } elseif ($is_selected) {
                $status = get_post_meta($post->ID, self::GALLERY_ERROR . $key, true)
                    ?: 'Brak pliku. Zapisz wpis, aby ponowić pobieranie.';
            }
            ?>
            <li>
                <label>
                    <input type="checkbox" name="mg_feed_gallery[]" value="<?php echo esc_attr($url); ?>"
                        <?php checked($is_selected); ?>>
                    <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">
                        <?php echo esc_html(rawurldecode($label)); ?>
                    </a>
                </label>
                <?php if ($can_upload): ?>
                    <input type="hidden" class="mg-feed-media-id" name="mg_feed_gallery_media[<?php echo esc_attr($key); ?>]"
                        value="<?php echo esc_attr((string) $override); ?>" <?php disabled(!$override); ?>>
                    <button type="button" class="button button-small mg-feed-pick-media">Wybierz z mediów</button>
                    <button type="button" class="button button-small mg-feed-reset-media" <?php echo $override ? '' : 'hidden'; ?>>Usuń przypisanie</button>
                <?php endif; ?>
                <span class="mg-feed-media-status" aria-live="polite"><?php echo esc_html($status); ?></span>
            </li>
            <?php
        }
        ?>
        </ul>
        <script>
            document.getElementById('mg-feed-gallery-select-tail').addEventListener('click', () => {
                const count = document.getElementById('mg-feed-gallery-count').valueAsNumber;
                if (!Number.isInteger(count) || count < 1) {
                    return;
                }
                const images = document.querySelectorAll('#mg-feed-gallery-images input[type="checkbox"]');
                Array.from(images).slice(0, count).forEach((image) => {
                    image.checked = true;
                });
            });
            document.getElementById('mg-feed-gallery-images').addEventListener('click', (event) => {
                const button = event.target.closest('button');
                if (!button) {
                    return;
                }
                const row = button.closest('li');
                const field = row.querySelector('.mg-feed-media-id');
                const status = row.querySelector('.mg-feed-media-status');
                const reset = row.querySelector('.mg-feed-reset-media');
                if (button === reset) {
                    field.value = '0';
                    field.disabled = false;
                    reset.hidden = true;
                    status.textContent = 'Zapisz produkt, aby usunąć ręczne przypisanie.';
                } else if (button.classList.contains('mg-feed-pick-media') && window.wp?.media) {
                    const picker = wp.media({title: 'Wybierz zdjęcie do galerii', library: {type: 'image'}});
                    picker.on('select', () => {
                        const image = picker.state().get('selection').first().toJSON();
                        field.value = image.id;
                        field.disabled = false;
                        reset.hidden = false;
                        row.querySelector('input[type="checkbox"]').checked = true;
                        status.textContent = 'Wybrano plik: ' + image.filename + '. Zapisz produkt.';
                    });
                    picker.open();
                }
            });
        </script>
        <?php
    }

    public static function save_gallery(int $post_id): void {
        $nonce = $_POST['mg_feed_gallery_nonce'] ?? '';
        if (!is_string($nonce) || !wp_verify_nonce(wp_unslash($nonce), 'mg_feed_gallery_' . $post_id)
            || !current_user_can('edit_post', $post_id) || wp_is_post_autosave($post_id)) {
            return;
        }

        $requested = $_POST['mg_feed_gallery'] ?? [];
        $available = self::gallery_options($post_id);
        $selection = is_array($requested)
            ? array_intersect($available, wp_unslash(array_filter($requested, 'is_string')))
            : [];
        update_post_meta($post_id, self::GALLERY_SELECTION, wp_slash(array_values($selection)));

        if (current_user_can('upload_files') && isset($_POST['mg_feed_gallery_media']) && is_array($_POST['mg_feed_gallery_media'])) {
            $overrides = self::gallery_media_overrides($post_id);
            $valid_keys = array_flip(array_map(static fn($url) => hash('sha256', $url), $available));
            foreach (array_intersect_key($_POST['mg_feed_gallery_media'], $valid_keys) as $key => $value) {
                if (!is_string($value)) {
                    continue;
                }
                $attachment = absint($value);
                if ($value === '0') {
                    unset($overrides[$key]);
                } elseif (wp_attachment_is_image($attachment) && current_user_can('edit_post', $attachment)) {
                    $overrides[$key] = $attachment;
                }
            }
            update_post_meta($post_id, self::GALLERY_MEDIA, $overrides);
        }

        $attachments = self::gallery_attachments($post_id);
        $time = time();
        foreach ($selection as $url) {
            $args = [$post_id, $url];
            if (!isset($attachments[$url]) && !wp_next_scheduled(self::GALLERY_EVENT, $args)) {
                wp_schedule_single_event($time, self::GALLERY_EVENT, $args);
                $time += 5;
            }
        }
        self::refresh_gallery($post_id);
    }

    private static function gallery_options(int $post_id): array {
        $main = get_post_meta($post_id, '_mg_feed_image_link', true);
        $extra = get_post_meta($post_id, self::EXTRA_IMAGES, true);
        $urls = array_merge([$main], is_array($extra) ? $extra : []);
        return array_values(array_unique(array_filter($urls)));
    }

    private static function available_attachments(int $post_id): array {
        $ids = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'post_parent' => $post_id,
            'numberposts' => -1,
            'fields' => 'ids',
            'meta_key' => self::IMAGE_SOURCE,
        ]);
        $sources = [];
        foreach ($ids as $id) {
            if (wp_attachment_is_image($id)) {
                $sources[get_post_meta($id, self::IMAGE_SOURCE, true)] = $id;
            }
        }
        return $sources;
    }

    private static function gallery_media_overrides(int $post_id): array {
        $overrides = get_post_meta($post_id, self::GALLERY_MEDIA, true);
        return is_array($overrides) ? $overrides : [];
    }

    private static function gallery_attachments(int $post_id): array {
        $attachments = self::available_attachments($post_id);
        $overrides = self::gallery_media_overrides($post_id);
        if (!$overrides) {
            return $attachments;
        }
        foreach (self::gallery_options($post_id) as $url) {
            $id = $overrides[hash('sha256', $url)] ?? 0;
            if ($id && get_post_status($id) !== 'trash' && wp_attachment_is_image($id)) {
                $attachments[$url] = $id;
            }
        }
        return $attachments;
    }

    private static function refresh_gallery(int $post_id): void {
        $content = get_post_field('post_content', $post_id, 'raw');
        $description = self::without_gallery($content);
        $selection = get_post_meta($post_id, self::GALLERY_SELECTION, true);
        if (is_array($selection) && $selection) {
            $sources = self::gallery_attachments($post_id);
            $ids = [];
            foreach ($selection as $url) {
                if (isset($sources[$url])) {
                    $ids[] = $sources[$url];
                }
            }
            if ($ids) {
                $description .= "\n\n<!-- mg-feed-gallery:start -->\n"
                    . '[gallery ids="' . implode(',', $ids) . '"]'
                    . "\n<!-- mg-feed-gallery:end -->";
            }
        }

        if ($description !== $content) {
            remove_action('save_post_' . self::POST_TYPE, [self::class, 'save_gallery']);
            try {
                wp_update_post(wp_slash(['ID' => $post_id, 'post_content' => $description]));
            } finally {
                add_action('save_post_' . self::POST_TYPE, [self::class, 'save_gallery']);
            }
        }
    }

    private static function without_gallery(string $content): string {
        return preg_replace('~\n*<!-- mg-feed-gallery:start -->.*?<!-- mg-feed-gallery:end -->~s', '', $content);
    }

    public static function render_details(WP_Post $post): void {
        echo '<dl>';
        foreach (self::FIELDS as $field => $label) {
            $value = get_post_meta($post->ID, '_mg_feed_' . $field, true);
            if ($value !== '') {
                printf('<dt><strong>%s</strong></dt><dd>%s</dd>', esc_html($label), esc_html($value));
            }
        }
        echo '</dl>';

        $image_error = get_post_meta($post->ID, self::IMAGE_ERROR, true);
        if ($image_error) {
            echo '<p>' . esc_html($image_error) . '</p>';
        } elseif (wp_next_scheduled(self::IMAGE_EVENT, [$post->ID])) {
            echo '<p>Zdjęcie oczekuje na pobranie przez WP-Cron.</p>';
        }
    }

    public static function handle_import(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Import wymaga uprawnień administratora.', '', ['response' => 403]);
        }
        check_admin_referer('mg_feed_import');

        $raw_url = $_POST['feed_url'] ?? '';
        $raw_url = is_string($raw_url) ? trim(wp_unslash($raw_url)) : '';
        $url = esc_url_raw($raw_url, ['https', 'http']);
        $parts = wp_parse_url($url);
        if (!preg_match('~^https?://~i', $raw_url) || !$parts || empty($parts['host'])
            || isset($parts['user']) || isset($parts['pass'])) {
            wp_die('Podaj pełny adres feeda zaczynający się od https:// lub http://.', '', ['back_link' => true]);
        }

        $file = $_FILES['feed_file'] ?? [];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            $result = self::import($url);
        } else {
            $body = self::read_uploaded_xml($file);
            $result = is_wp_error($body) ? $body : self::import_xml($body, $url);
        }
        if (is_wp_error($result)) {
            wp_die(esc_html($result->get_error_message()), 'Import XML', ['back_link' => true]);
        }

        update_option(self::OPTION, $url, false);
        $page = admin_url('edit.php?post_type=' . self::POST_TYPE . '&page=mg-feed-import');
        wp_safe_redirect(add_query_arg($result, $page));
        exit;
    }

    private static function import(string $url) {
        if (!wp_http_validate_url($url)) {
            return new WP_Error('mg_feed_url', 'WordPress odrzucił adres przed pobraniem feeda. Sprawdź, czy serwer WordPressa rozwiązuje domenę na publiczny adres IP i może użyć wskazanego portu. Możesz też pobrać feed w przeglądarce i wgrać go jako plik XML.');
        }

        $response = wp_safe_remote_get($url, [
            'timeout' => 45,
            'redirection' => 3,
            'limit_response_size' => self::MAX_BYTES + 1,
        ]);
        if (is_wp_error($response)) {
            return new WP_Error('mg_feed_download', 'Nie udało się pobrać feeda. ' . $response->get_error_message());
        }

        $status = wp_remote_retrieve_response_code($response);
        if ($status !== 200) {
            return new WP_Error('mg_feed_http', sprintf('Serwer feeda zwrócił HTTP %s.', $status));
        }

        return self::import_xml(wp_remote_retrieve_body($response), $url);
    }

    private static function read_uploaded_xml(array $file) {
        if (in_array($file['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
            return new WP_Error('mg_feed_upload_limit', 'Plik przekracza limit przesyłania PHP na serwerze WordPressa.');
        }

        $path = $file['tmp_name'] ?? '';
        if ($file['error'] !== UPLOAD_ERR_OK || !is_string($path) || !is_uploaded_file($path)) {
            return new WP_Error('mg_feed_upload', 'Nie udało się przesłać pliku XML.');
        }

        $body = file_get_contents($path, false, null, 0, self::MAX_BYTES + 1);
        if ($body === false) {
            return new WP_Error('mg_feed_upload_read', 'Nie udało się odczytać pliku XML.');
        }

        if (strlen($body) <= self::MAX_BYTES) {
            $browser_notice = 'This XML file does not appear to have any style information associated with it. The document tree is shown below.';
            foreach (["\r\n", "\n"] as $newline) {
                $prefix = $browser_notice . $newline;
                if (str_starts_with($body, $prefix)) {
                    return substr($body, strlen($prefix));
                }
            }
        }

        return $body;
    }

    private static function import_xml(string $body, string $url) {
        global $wpdb;

        if (!class_exists(DOMDocument::class)) {
            return new WP_Error('mg_feed_dom', 'Import wymaga rozszerzenia DOM w PHP.');
        }

        if ($body === '' || strlen($body) > self::MAX_BYTES) {
            return new WP_Error('mg_feed_size', 'Feed jest pusty lub przekracza 16 MiB.');
        }

        $items = self::parse($body);
        if (is_wp_error($items)) {
            return $items;
        }

        $lock = 'mg_feed_' . md5(DB_NAME . '|' . $wpdb->posts);
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $lock)) !== '1') {
            return new WP_Error('mg_feed_lock', 'Nie udało się uzyskać blokady importu. Sprawdź, czy trwa inny import.');
        }

        try {
            return self::save_items($items, $url);
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }

    private static function parse(string $body) {
        $previous = libxml_use_internal_errors(true);
        $document = new DOMDocument();

        try {
            $loaded = $document->loadXML($body, LIBXML_NONET);
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        if (!$loaded || $document->doctype !== null) {
            return new WP_Error('mg_feed_xml', 'Feed musi być poprawnym XML bez deklaracji DOCTYPE.');
        }

        $xpath = new DOMXPath($document);
        $xpath->registerNamespace('g', self::GOOGLE_NS);
        $nodes = $xpath->query('/rss/channel/item');
        if (!$nodes->length) {
            return new WP_Error('mg_feed_items', 'Nie znaleziono produktów w strukturze RSS rss/channel/item.');
        }

        if ($nodes->length > self::MAX_PRODUCTS) {
            return new WP_Error('mg_feed_limit', 'Feed przekracza limit 5000 pozycji na import.');
        }

        $items = [];
        foreach ($nodes as $node) {
            $item = [];
            foreach (array_merge(['title', 'description'], array_keys(self::FIELDS)) as $field) {
                $value = $xpath->evaluate('string(g:' . $field . ')', $node);
                $item[$field] = trim($value !== '' ? $value : $xpath->evaluate('string(' . $field . ')', $node));
            }
            $item['additional_images'] = [];
            foreach ($xpath->query('g:additional_image_link | additional_image_link', $node) as $image) {
                $url = esc_url_raw(trim($image->textContent), ['https', 'http']);
                if ($url !== '') {
                    $item['additional_images'][] = set_url_scheme($url, 'https');
                }
            }
            $items[] = $item;
        }

        return $items;
    }

    private static function save_items(array $items, string $url) {
        $term = term_exists(self::TERM, self::TAXONOMY);
        if (!$term) {
            $term = wp_insert_term('Importowane produkty', self::TAXONOMY, ['slug' => self::TERM]);
        }
        if (is_wp_error($term)) {
            return $term;
        }

        $term_id = (int) $term['term_id'];
        $counts = ['imported' => 0, 'skipped' => 0, 'failed' => 0];
        $image_time = time();

        foreach ($items as $item) {
            $title = sanitize_text_field($item['title']);
            if ($item['id'] === '' || $title === '') {
                ++$counts['skipped'];
                continue;
            }

            $key = hash('sha256', $url . "\0" . $item['id']);
            $existing = get_posts([
                'post_type' => self::POST_TYPE,
                'post_status' => ['private', 'publish', 'draft', 'pending', 'future'],
                'posts_per_page' => 1,
                'fields' => 'ids',
                'meta_key' => '_mg_feed_key',
                'meta_value' => $key,
                'no_found_rows' => true,
            ]);

            $description = wp_kses_post($item['description']);
            $link = esc_url_raw($item['link'], ['https', 'http']);
            $excerpt = wp_trim_words(wp_strip_all_tags($description, true), 30, '…');
            if ($link !== '') {
                $description .= "\n\n" . esc_html($link);
                $excerpt = trim($excerpt . "\n\n" . esc_html($link));
            }
            $post = [
                'post_type' => self::POST_TYPE,
                'post_status' => 'private',
                'post_title' => $title,
                'post_content' => $description,
                'post_excerpt' => $excerpt,
            ];
            if ($existing) {
                $post['ID'] = $existing[0];
            }

            $post_id = wp_insert_post(wp_slash($post), true);
            if (is_wp_error($post_id) || !$post_id) {
                ++$counts['failed'];
                continue;
            }

            $assigned = wp_set_object_terms($post_id, [$term_id], self::TAXONOMY, true);
            if (is_wp_error($assigned)) {
                if (!$existing) {
                    wp_delete_post($post_id, true);
                }
                ++$counts['failed'];
                continue;
            }

            update_post_meta($post_id, '_mg_feed_key', $key);
            foreach (array_keys(self::FIELDS) as $field) {
                $value = $item[$field];
                $value = in_array($field, ['link', 'image_link'], true)
                    ? esc_url_raw($value, ['https', 'http'])
                    : sanitize_text_field($value);
                if ($value === '') {
                    delete_post_meta($post_id, '_mg_feed_' . $field);
                } else {
                    update_post_meta($post_id, '_mg_feed_' . $field, wp_slash($value));
                }
            }
            update_post_meta($post_id, self::EXTRA_IMAGES, wp_slash(array_values(array_unique($item['additional_images']))));
            if (get_post_meta($post_id, self::GALLERY_SELECTION, true)) {
                self::refresh_gallery($post_id);
            }
            $image_url = get_post_meta($post_id, '_mg_feed_image_link', true);
            $image = get_post_thumbnail_id($post_id);
            $image_source = $image ? get_post_meta($image, self::IMAGE_SOURCE, true) : '';
            if ($image_url && (!$image || ($image_source && $image_source !== $image_url))
                && !wp_next_scheduled(self::IMAGE_EVENT, [$post_id])) {
                $scheduled = wp_schedule_single_event($image_time, self::IMAGE_EVENT, [$post_id]);
                if ($scheduled) {
                    $image_time += 5;
                    delete_post_meta($post_id, self::IMAGE_ERROR);
                } else {
                    update_post_meta($post_id, self::IMAGE_ERROR, 'Nie udało się zaplanować pobrania zdjęcia.');
                }
            }
            ++$counts['imported'];
        }

        return $counts;
    }

    public static function import_featured_image(int $post_id): void {
        if (get_post_type($post_id) !== self::POST_TYPE || get_post_status($post_id) === 'trash') {
            return;
        }

        $url = get_post_meta($post_id, '_mg_feed_image_link', true);
        $image = get_post_thumbnail_id($post_id);
        $source = $image ? get_post_meta($image, self::IMAGE_SOURCE, true) : '';
        if (!$url || ($image && (!$source || $source === $url))) {
            return;
        }

        $result = self::get_or_download_image($post_id, $url);
        if (!is_wp_error($result) && !set_post_thumbnail($post_id, $result)) {
            $result = new WP_Error('mg_feed_image_thumbnail', 'WordPress nie ustawił obrazka wyróżniającego.');
        }
        if (is_wp_error($result)) {
            update_post_meta($post_id, self::IMAGE_ERROR, $result->get_error_message());
        } else {
            delete_post_meta($post_id, self::IMAGE_ERROR);
        }
    }

    public static function import_gallery_image(int $post_id, string $url): void {
        if (get_post_type($post_id) !== self::POST_TYPE || get_post_status($post_id) === 'trash') {
            return;
        }
        $selection = get_post_meta($post_id, self::GALLERY_SELECTION, true);
        if (!is_array($selection) || !in_array($url, $selection, true)) {
            return;
        }
        $key = self::GALLERY_ERROR . hash('sha256', $url);
        $attachments = self::gallery_attachments($post_id);
        $result = $attachments[$url] ?? self::get_or_download_image($post_id, $url);
        if (is_wp_error($result)) {
            update_post_meta($post_id, $key, wp_slash($result->get_error_message()));
            return;
        }
        delete_post_meta($post_id, $key);
        self::refresh_gallery($post_id);
    }

    private static function get_or_download_image(int $post_id, string $url) {
        $images = self::available_attachments($post_id);
        if (isset($images[$url])) {
            return $images[$url];
        }

        if (wp_parse_url($url, PHP_URL_SCHEME) !== 'https' || !wp_http_validate_url($url)) {
            return new WP_Error('mg_feed_image_url', 'WordPress odrzucił adres zdjęcia. Sprawdź HTTPS i DNS na serwerze lub przypisz plik ręcznie.');
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $file = wp_tempnam('mg-feed-image');
        if (!$file) {
            return new WP_Error('mg_feed_image_temp', 'Nie udało się utworzyć pliku tymczasowego na zdjęcie.');
        }

        try {
            $response = wp_safe_remote_get($url, [
                'timeout' => 15,
                'redirection' => 0,
                'stream' => true,
                'filename' => $file,
                'limit_response_size' => self::MAX_IMAGE_BYTES + 1,
            ]);
            if (is_wp_error($response)) {
                return new WP_Error('mg_feed_image_http', 'Nie udało się pobrać zdjęcia: ' . $response->get_error_message());
            }
            $status = wp_remote_retrieve_response_code($response);
            if ($status !== 200) {
                return new WP_Error('mg_feed_image_http', sprintf('Serwer zdjęcia zwrócił HTTP %s.', $status));
            }

            clearstatcache(true, $file);
            $size = filesize($file);
            $dimensions = wp_getimagesize($file);
            $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            $extension = $extensions[$dimensions['mime'] ?? ''] ?? '';
            if (!$size || $size > self::MAX_IMAGE_BYTES || !$extension || $dimensions[0] * $dimensions[1] > 16000000) {
                return new WP_Error('mg_feed_image_format', 'Zdjęcie musi być plikiem JPEG, PNG lub WebP do 8 MiB i 16 megapikseli.');
            }

            $attachment = media_handle_sideload([
                'name' => sprintf('produkt-feed-%d.%s', $post_id, $extension),
                'tmp_name' => $file,
            ], $post_id);
            if (is_wp_error($attachment)) {
                return new WP_Error('mg_feed_image_media', 'WordPress nie zapisał zdjęcia w bibliotece mediów.');
            }

            update_post_meta($attachment, self::IMAGE_SOURCE, $url);
            return $attachment;
        } finally {
            if (is_file($file)) {
                wp_delete_file($file);
            }
        }
    }
}

MG_Feed_Import::boot();
